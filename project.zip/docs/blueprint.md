# **App Name**: Assistente Jurídico

## Core Features:

- Entrada de Texto Jurídico: Campo de entrada onde o usuário pode colar ou digitar texto jurídico (contrato, depoimento, etc.)
- Extração de Entidades-Chave: O aplicativo utiliza uma ferramenta sofisticada para identificar entidades-chave (pessoas, empresas, organizações) dentro do documento jurídico. Ele utiliza técnicas de processamento de linguagem natural para extrair e categorizar essas entidades com precisão.
- Localizador de Contexto de Entidades: Análise com tecnologia de IA que identifica todas as instâncias e contextos em que as entidades identificadas são mencionadas ao longo do documento jurídico. Ele pode então encontrar todas as seções do documento onde cada entidade identificada é discutida.
- Exibição da Lista de Entidades: Uma seção da interface do usuário que lista todas as entidades encontradas no texto.
- Visualizador de Localização de Contexto: Um componente da interface do usuário para visualizar os diferentes locais dentro do documento jurídico onde as entidades são referenciadas.

## Style Guidelines:

- Cor primária: Azul escuro (#2c3e50) para transmitir profissionalismo e confiança.
- Cor secundária: Cinza claro (#ecf0f1) para fundos limpos e contraste sutil.
- Destaque: Azul-petróleo (#3498db) para elementos interativos e destaque de informações importantes.
- Layout limpo e estruturado para facilitar a navegação e a legibilidade.
- Use ícones minimalistas e profissionais para representar entidades e ações.
- Transições e animações sutis para uma experiência do usuário impecável.
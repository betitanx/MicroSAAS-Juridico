// src/ai/flows/extract-legal-entities.ts
'use server';
/**
 * @fileOverview Extracts key entities (people, companies, organizations) from legal text.
 *
 * - extractLegalEntities - A function that extracts legal entities from a given text.
 * - ExtractLegalEntitiesInput - The input type for the extractLegalEntities function.
 * - ExtractLegalEntitiesOutput - The return type for the extractLegalEntities function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ExtractLegalEntitiesInputSchema = z.object({
  legalText: z.string().describe('The legal text to extract entities from.'),
});
export type ExtractLegalEntitiesInput = z.infer<typeof ExtractLegalEntitiesInputSchema>;

const LegalEntitySchema = z.object({
  name: z.string().describe('The name of the entity.'),
  type: z.enum(['person', 'company', 'organization']).describe('The type of entity.'),
});

const ExtractLegalEntitiesOutputSchema = z.object({
  entities: z.array(LegalEntitySchema).describe('The extracted legal entities.'),
});
export type ExtractLegalEntitiesOutput = z.infer<typeof ExtractLegalEntitiesOutputSchema>;

export async function extractLegalEntities(input: ExtractLegalEntitiesInput): Promise<ExtractLegalEntitiesOutput> {
  return extractLegalEntitiesFlow(input);
}

const extractLegalEntitiesPrompt = ai.definePrompt({
  name: 'extractLegalEntitiesPrompt',
  input: {schema: ExtractLegalEntitiesInputSchema},
  output: {schema: ExtractLegalEntitiesOutputSchema},
  config: { temperature: 0.3 },
  prompt: `Você é um assistente jurídico especialista. Sua tarefa é extrair entidades-chave (pessoas, empresas e organizações) do texto jurídico fornecido.

Texto Jurídico:
\`\`\`
{{{legalText}}}
\`\`\`

Instruções:
1. Analise o "Texto Jurídico" cuidadosamente.
2. Identifique todas as pessoas (indivíduos), empresas (entidades comerciais) e organizações (outras instituições, associações, órgãos públicos etc.) mencionadas.
3. Para cada entidade identificada, forneça:
    - 'name': O nome completo da entidade como aparece no texto.
    - 'type': O tipo da entidade, que deve ser uma das seguintes strings: "person", "company", ou "organization".
4. Se nenhuma entidade for encontrada, retorne um array vazio para 'entities'.

Retorne o resultado como um objeto JSON contendo uma chave "entities", que é um array de objetos, onde cada objeto representa uma entidade e segue o schema { "name": "string", "type": "string (person|company|organization)" }.

Exemplo de saída esperada (se entidades forem encontradas):
{
  "entities": [
    { "name": "João Silva", "type": "person" },
    { "name": "Empresa XYZ Ltda.", "type": "company" },
    { "name": "Tribunal de Justiça", "type": "organization" }
  ]
}

Exemplo de saída esperada (se nenhuma entidade for encontrada):
{
  "entities": []
}
`,
});

const extractLegalEntitiesFlow = ai.defineFlow(
  {
    name: 'extractLegalEntitiesFlow',
    inputSchema: ExtractLegalEntitiesInputSchema,
    outputSchema: ExtractLegalEntitiesOutputSchema,
  },
  async input => {
     if (!input.legalText || input.legalText.trim().length < 50) { // Increased minimum text length
       console.warn("Entity extraction: Input text too short.");
       return { entities: [] }; // Return empty if input is too short
     }
     try {
        const {output} = await extractLegalEntitiesPrompt(input);
        if (output && Array.isArray(output.entities)) {
             // Basic validation: Ensure names and types are present and non-empty
             const validatedEntities = output.entities.filter(e => e.name && e.name.trim() !== '' && e.type);
             if (validatedEntities.length !== output.entities.length) {
                console.warn("Entity extraction: Some entities filtered due to missing name/type.", output.entities);
             }
             return { entities: validatedEntities };
        }
        console.warn("Entity extraction model returned malformed output or no entities array:", output);
        return { entities: [] }; // Return empty if output is malformed or entities array is missing
     } catch (error) {
         console.error("Error during entity extraction flow:", error);
         return { entities: [] }; // Return empty list on error
     }
  }
);

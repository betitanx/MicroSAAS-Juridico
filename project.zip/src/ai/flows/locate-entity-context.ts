// Locate entity context flow
'use server';

/**
 * @fileOverview Locates the context of a given entity within a legal text.
 *
 * - locateEntityContext - A function that finds all instances and contexts where a specified entity is mentioned in a legal document.
 * - LocateEntityContextInput - The input type for the locateEntityContext function.
 * - LocateEntityContextOutput - The return type for the locateEntityContext function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const LocateEntityContextInputSchema = z.object({
  legalText: z.string().describe('The legal text to analyze.'),
  entity: z.string().describe('The entity to locate within the legal text.'),
});
export type LocateEntityContextInput = z.infer<typeof LocateEntityContextInputSchema>;

const LocateEntityContextOutputSchema = z.object({
  contexts: z
    .array(z.string())
    .describe('An array of verbatim contexts where the entity is explicitly mentioned.'),
});
export type LocateEntityContextOutput = z.infer<typeof LocateEntityContextOutputSchema>;

export async function locateEntityContext(input: LocateEntityContextInput): Promise<LocateEntityContextOutput> {
  return locateEntityContextFlow(input);
}

const prompt = ai.definePrompt({
  name: 'locateEntityContextPrompt',
  input: {schema: LocateEntityContextInputSchema},
  output: {schema: LocateEntityContextOutputSchema},
  config: { temperature: 0.3 },
  prompt: `Você é um assistente de IA especializado em análise de texto jurídico. Sua tarefa é identificar e extrair **trechos de texto literais (contextos)** do texto jurídico fornecido onde a entidade específica **{{{entity}}}** é **mencionada explícita e literalmente**.

Texto Jurídico:
\`\`\`
{{{legalText}}}
\`\`\`

Entidade a localizar: "{{{entity}}}"

Instruções:
1. Examine o "Texto Jurídico" completamente.
2. Identifique todas as frases ou parágrafos onde a **string exata "{{{entity}}}"** (correspondência sem distinção entre maiúsculas e minúsculas é aceitável apenas se apropriado para nomes próprios/nomes legais, caso contrário, diferencie maiúsculas e minúsculas) está presente.
3. Para cada instância identificada, extraia o trecho de texto que fornece contexto claro sobre o papel ou ação da entidade naquela parte específica do documento.
4. **CRÍTICO:** Cada trecho de contexto retornado **DEVE conter a string exata da entidade "{{{entity}}}"** dentro dele. **NÃO** retorne trechos onde a entidade está apenas implícita, referida por pronomes ou relacionada, mas não explicitamente nomeada. **NÃO** resuma ou parafraseie o contexto; extraia-o literalmente.
5. Procure por contextos que sejam concisos e informativos.
6. Retorne os contextos como um array JSON de strings. Se nenhum contexto contendo a string exata da entidade for encontrado, retorne um array vazio (\`[]\`).`,
});

const locateEntityContextFlow = ai.defineFlow(
  {
    name: 'locateEntityContextFlow',
    inputSchema: LocateEntityContextInputSchema,
    outputSchema: LocateEntityContextOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    // Ensure output is not null and contexts is an array, even if empty
    // Filter results on the backend for extra safety, ensuring the entity is actually present (case-insensitive check for flexibility)
    if (output && Array.isArray(output.contexts)) {
       const filteredContexts = output.contexts.filter(context =>
            context.toLowerCase().includes(input.entity.toLowerCase())
       );
      return { contexts: filteredContexts };
    }
    // Fallback to an empty contexts array if output is malformed or null
    return { contexts: [] };
  }
);

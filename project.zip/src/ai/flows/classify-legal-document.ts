'use server';
/**
 * @fileOverview Classifies the type of a legal document.
 *
 * - classifyLegalDocument - A function that classifies the type of the legal document.
 * - ClassifyLegalDocumentInput - The input type for the classifyLegalDocument function.
 * - ClassifyLegalDocumentOutput - The return type for the classifyLegalDocument function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ClassifyLegalDocumentInputSchema = z.object({
  legalText: z.string().describe('The legal text to classify.'),
});
export type ClassifyLegalDocumentInput = z.infer<typeof ClassifyLegalDocumentInputSchema>;

const ClassifyLegalDocumentOutputSchema = z.object({
  documentType: z.string().describe('The classified type of the legal document (e.g., Petição Inicial, Contestação, Recurso, Contrato, Procuração, Sentença, Acórdão, Notificação, etc.) or "Informação Insuficiente para Classificar" or "Erro na Classificação".'),
});
export type ClassifyLegalDocumentOutput = z.infer<typeof ClassifyLegalDocumentOutputSchema>;

export async function classifyLegalDocument(input: ClassifyLegalDocumentInput): Promise<ClassifyLegalDocumentOutput> {
  return classifyLegalDocumentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'classifyLegalDocumentPrompt',
  input: {schema: ClassifyLegalDocumentInputSchema},
  output: {schema: ClassifyLegalDocumentOutputSchema},
  config: { temperature: 0.3 },
  prompt: `Você é um assistente jurídico especialista em identificar tipos de peças processuais e documentos legais em português do Brasil. Sua tarefa é classificar o tipo do documento jurídico fornecido.

Texto Jurídico:
\`\`\`
{{{legalText}}}
\`\`\`

Analise o texto fornecido e determine qual o tipo de documento jurídico ele representa. Considere os seguintes tipos comuns, mas não se limite a eles:
- Petição Inicial
- Contestação
- Réplica
- Recurso de Apelação
- Recurso Especial
- Recurso Extraordinário
- Agravo de Instrumento
- Embargos de Declaração
- Contrato (especificar o tipo se possível, ex: Contrato de Locação, Contrato Social)
- Procuração
- Notificação Extrajudicial
- Ata de Reunião
- Sentença
- Acórdão
- Despacho
- Alvará Judicial
- Termo de Audiência

Se o texto for muito curto ou não contiver informações suficientes para uma classificação segura, retorne "Informação insuficiente para classificar".
Se ocorrer algum erro durante a análise, retorne "Erro na classificação".

Retorne apenas o nome do tipo do documento classificado como uma string JSON.

Exemplo de saída válida: {"documentType": "Petição Inicial"}
Exemplo de saída válida: {"documentType": "Contrato de Prestação de Serviços"}
Exemplo de saída válida: {"documentType": "Informação Insuficiente para Classificar"}
`,
});

const classifyLegalDocumentFlow = ai.defineFlow(
  {
    name: 'classifyLegalDocumentFlow',
    inputSchema: ClassifyLegalDocumentInputSchema,
    outputSchema: ClassifyLegalDocumentOutputSchema,
  },
  async (input) => {
    // Add a basic check for minimum text length
    if (!input.legalText || input.legalText.trim().length < 50) { // Increased minimum length
      return { documentType: "Informação Insuficiente para Classificar" };
    }

    try {
      const {output} = await prompt(input);
      // Basic validation on the output
      if (output && typeof output.documentType === 'string' && output.documentType.trim() !== '') {
        return output;
      }
      // Fallback if the model returns an invalid/empty type
      console.warn("Classification model returned invalid output:", output);
      return { documentType: "Erro na Classificação" };
    } catch (error) {
      console.error("Error during document classification flow:", error);
      return { documentType: "Erro na Classificação" }; // Return specific error type
    }
  }
);

'use server';
/**
 * @fileOverview Generates a structured summary of a legal document.
 *
 * - summarizeLegalDocument - A function that generates a summary of the legal document.
 * - SummarizeLegalDocumentInput - The input type for the summarizeLegalDocument function.
 * - SummarizeLegalDocumentOutput - The return type for the summarizeLegalDocument function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SummarizeLegalDocumentInputSchema = z.object({
  legalText: z.string().describe('The legal text to summarize.'),
});
export type SummarizeLegalDocumentInput = z.infer<typeof SummarizeLegalDocumentInputSchema>;

const SummarizeLegalDocumentOutputSchema = z.object({
  overallSummary: z.string().describe('Um resumo **muito conciso** (3 frases no máximo) destacando **apenas o essencial** sobre o propósito geral ou o assunto principal do documento.'),
  mainRequests: z.array(z.string()).describe('Uma lista contendo **todos os pedidos presentes** e o que está sendo solicitado no documento.'),
  legalGrounds: z.array(z.string()).describe('Uma lista contendo **todos os argumentos jurídicos chave** que sustentam os pedidos.'),
  legalBasisCited: z.array(z.string()).describe('Uma lista das **fontes legais mais relevantes** (máximo 5 itens, como leis ou artigos principais) explicitamente citadas.'),
});
export type SummarizeLegalDocumentOutput = z.infer<typeof SummarizeLegalDocumentOutputSchema>;

export async function summarizeLegalDocument(input: SummarizeLegalDocumentInput): Promise<SummarizeLegalDocumentOutput> {
  return summarizeLegalDocumentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'summarizeLegalDocumentPrompt',
  input: {schema: SummarizeLegalDocumentInputSchema},
  output: {schema: SummarizeLegalDocumentOutputSchema},
  config: { temperature: 0.3 },
  prompt: `Você é um assistente jurídico altamente qualificado, especializado em analisar documentos legais e extrair **apenas as informações mais essenciais** de forma estruturada. Sua tarefa é analisar o texto jurídico fornecido e gerar um resumo **sucinto**.

Texto Jurídico:
\`\`\`
{{{legalText}}}
\`\`\`

Com base no texto acima, por favor, identifique e forneça de forma **breve e focada no essencial**:
1.  **Resumo Geral Essencial**: Um resumo **conciso** (3 frases no máximo) destacando **apenas o essencial** sobre o propósito geral ou o assunto principal do documento.
2.  **Todos os Pedidos no Contexto Jurídico**: Uma lista com **todos os pedidos** e o que está sendo solicitado no documento (MUITO IMPORTANTE E EXTREMAMENTE ESSENCIAL).
3.  **Fundamentos Jurídicos Chave**: Uma lista de **todos os argumentos jurídicos** que sustentam os pedidos (MUITO IMPORTANTE E ESSENCIAL).
4.  **Base Legal Principal Citada**: Uma lista das **fontes legais mais relevantes** (máximo 5 itens, como leis ou artigos principais) explicitamente citadas.

O objetivo é fornecer um "snapshot" de alto nível do documento. **Evite detalhes excessivos e foque na informação crítica.**
Se alguma seção não for aplicável ou não for encontrada no texto, retorne um array vazio para as listas ou uma string vazia para o resumo.
Siga estritamente o schema de saída JSON fornecido.`,
});

const summarizeLegalDocumentFlow = ai.defineFlow(
  {
    name: 'summarizeLegalDocumentFlow',
    inputSchema: SummarizeLegalDocumentInputSchema,
    outputSchema: SummarizeLegalDocumentOutputSchema,
  },
  async (input) => {
    if (!input.legalText || input.legalText.trim().length < 100) { // Minimum length for a meaningful summary
      return {
        overallSummary: "Informação insuficiente para resumir.",
        mainRequests: [],
        legalGrounds: [],
        legalBasisCited: [],
      };
    }

    try {
      const {output} = await prompt(input);
      if (output) {
        // Ensure arrays do not exceed max items if model doesn't respect it
        return {
          overallSummary: output.overallSummary,
          mainRequests: output.mainRequests.slice(0, 3),
          legalGrounds: output.legalGrounds.slice(0, 3),
          legalBasisCited: output.legalBasisCited.slice(0, 3),
        };
      }
      // Fallback if the model returns an invalid/empty type
      console.warn("Summarization model returned invalid output:", output);
      return {
        overallSummary: "Erro ao gerar resumo.",
        mainRequests: [],
        legalGrounds: [],
        legalBasisCited: [],
      };
    } catch (error) {
      console.error("Error during legal document summarization flow:", error);
      return {
        overallSummary: "Erro ao gerar resumo.",
        mainRequests: [],
        legalGrounds: [],
        legalBasisCited: [],
      };
    }
  }
);

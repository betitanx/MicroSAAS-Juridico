import { config } from 'dotenv';
config();

import '@/ai/flows/extract-legal-entities.ts';
import '@/ai/flows/locate-entity-context.ts';
import '@/ai/flows/classify-legal-document.ts'; // Added import for new flow
import '@/ai/flows/summarize-legal-document.ts'; // Added import for summary flow

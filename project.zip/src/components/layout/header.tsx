import { Scale } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-primary text-primary-foreground shadow-md">
      <div className="container mx-auto px-4 md:px-6 lg:px-8 py-4 flex items-center gap-3">
        <Scale className="h-8 w-8" />
        <h1 className="text-2xl font-semibold tracking-tight">AdvocIA</h1>
      </div>
    </header>
  );
}

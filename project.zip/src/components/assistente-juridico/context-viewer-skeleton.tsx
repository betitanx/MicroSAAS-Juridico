import { Skeleton } from "@/components/ui/skeleton";

export function ContextViewerSkeleton() {
  return (
    <div className="space-y-4">
       <Skeleton className="h-6 w-1/2 mb-4" />
      {[...Array(3)].map((_, i) => (
        <div key={i} className="p-4 bg-card rounded-md shadow-sm space-y-2">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-5/6" />
          <Skeleton className="h-4 w-3/4" />
        </div>
      ))}
    </div>
  );
}
"use client";

import type { ExtractLegalEntitiesOutput } from '@/ai/flows/extract-legal-entities';
import { cn } from '@/lib/utils';
import { Users, Building2, Library, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

type LegalEntity = ExtractLegalEntitiesOutput['entities'][number];

interface EntityListItemProps {
  entity: LegalEntity;
  isSelected: boolean;
  onSelect: () => void;
}

const iconMap = {
  person: <Users className="h-5 w-5 text-accent" />,
  company: <Building2 className="h-5 w-5 text-accent" />,
  organization: <Library className="h-5 w-5 text-accent" />,
};

export function EntityListItem({ entity, isSelected, onSelect }: EntityListItemProps) {
  const IconComponent = iconMap[entity.type] || <AlertCircle className="h-5 w-5 text-destructive" />;

  return (
    <Button
      variant="ghost"
      onClick={onSelect}
      className={cn(
        "w-full justify-start p-3 text-left h-auto transition-all duration-150 ease-in-out",
        "hover:bg-secondary hover:shadow-sm",
        isSelected ? "bg-accent text-accent-foreground hover:bg-accent/90 shadow-md ring-2 ring-accent/50" : "bg-card"
      )}
      aria-pressed={isSelected}
    >
      <div className="flex items-center gap-3 w-full">
        <span className="p-2 bg-secondary rounded-md">{IconComponent}</span>
        <div className="flex-grow">
          <p className={cn("font-medium truncate", isSelected ? "text-accent-foreground" : "text-foreground")}>
            {entity.name}
          </p>
          <p className={cn("text-xs capitalize", isSelected ? "text-accent-foreground/80" : "text-muted-foreground")}>
            {entity.type === 'person' ? 'Pessoa' : entity.type === 'company' ? 'Empresa' : 'Organização'}
          </p>
        </div>
      </div>
    </Button>
  );
}
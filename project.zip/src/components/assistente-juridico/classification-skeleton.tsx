import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

export function ClassificationSkeleton() {
  return (
    <Card className="shadow-lg">
      <CardHeader>
        <Skeleton className="h-6 w-3/4 mb-1" /> {/* Title */}
        <Skeleton className="h-4 w-1/2" /> {/* Description */}
      </CardHeader>
      <CardContent>
        <Skeleton className="h-8 w-full" /> {/* Content area */}
      </CardContent>
    </Card>
  );
}

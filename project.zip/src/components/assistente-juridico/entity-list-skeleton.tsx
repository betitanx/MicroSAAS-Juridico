import { Skeleton } from "@/components/ui/skeleton";

export function EntityListSkeleton() {
  return (
    <div className="space-y-2">
      {[...Array(3)].map((_, i) => (
        <div key={i} className="flex items-center space-x-3 p-3 bg-card rounded-md shadow-sm">
          <Skeleton className="h-10 w-10 rounded-md" />
          <div className="space-y-1.5 flex-grow">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-3 w-1/2" />
          </div>
        </div>
      ))}
    </div>
  );
}
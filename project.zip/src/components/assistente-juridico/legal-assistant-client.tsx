// src/components/assistente-juridico/legal-assistant-client.tsx
"use client";

import { useState, useRef, type ChangeEvent, Fragment } from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { extractLegalEntities, type ExtractLegalEntitiesOutput } from '@/ai/flows/extract-legal-entities';
import { locateEntityContext } from '@/ai/flows/locate-entity-context';
import { classifyLegalDocument } from '@/ai/flows/classify-legal-document';
import { summarizeLegalDocument, type SummarizeLegalDocumentOutput } from '@/ai/flows/summarize-legal-document'; // Import summary flow
import { EntityListItem } from './entity-list-item';
import { EntityListSkeleton } from './entity-list-skeleton';
import { ContextViewerSkeleton } from './context-viewer-skeleton';
import { ClassificationSkeleton } from './classification-skeleton';
import { SummarySkeleton } from './summary-skeleton'; // Import summary skeleton
import { Loader2, FileText, ListChecks, SearchCheck, AlertTriangle, Upload, X, Gavel, ScrollText } from 'lucide-react'; // Added ScrollText icon
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';

type LegalEntity = ExtractLegalEntitiesOutput['entities'][number];

// Helper function to highlight the entity in the text
const highlightEntity = (text: string, entityToHighlight: string) => {
    if (!entityToHighlight || !text) {
      return text;
    }
    const escapedEntity = entityToHighlight.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${escapedEntity})`, 'gi');
    const parts = text.split(regex);

    return parts.map((part, index) =>
      regex.test(part) ? (
        <span key={index} className="bg-yellow-300 font-semibold text-yellow-900 rounded px-1 py-0.5 mx-[1px]">
          {part}
        </span>
      ) : (
        <Fragment key={index}>{part}</Fragment>
      )
    );
  };


export default function LegalAssistantClient() {
  const [legalText, setLegalText] = useState<string>('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [entities, setEntities] = useState<LegalEntity[]>([]);
  const [selectedEntity, setSelectedEntity] = useState<LegalEntity | null>(null);
  const [selectedEntityContexts, setSelectedEntityContexts] = useState<string[]>([]);
  const [documentType, setDocumentType] = useState<string | null>(null);
  const [legalSummary, setLegalSummary] = useState<SummarizeLegalDocumentOutput | null>(null); // State for summary
  const [isLoadingAnalysis, setIsLoadingAnalysis] = useState<boolean>(false);
  const [isLoadingContext, setIsLoadingContext] = useState<boolean>(false);
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleTextChange = (e: ChangeEvent<HTMLTextAreaElement>) => {
    setLegalText(e.target.value);
    if (selectedFile) {
      clearFileSelection();
    }
    setEntities([]);
    setSelectedEntity(null);
    setSelectedEntityContexts([]);
    setDocumentType(null);
    setLegalSummary(null); // Clear summary
  };

  const clearFileSelection = () => {
      setSelectedFile(null);
      setFileName(null);
      setLegalText('');
       setEntities([]);
       setSelectedEntity(null);
       setSelectedEntityContexts([]);
       setDocumentType(null);
       setLegalSummary(null); // Clear summary
      if (fileInputRef.current) {
          fileInputRef.current.value = '';
      }
  }

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
     setEntities([]);
     setSelectedEntity(null);
     setSelectedEntityContexts([]);
     setDocumentType(null);
     setLegalSummary(null); // Clear summary

    if (file) {
      if (file.type === 'text/plain') {
        setSelectedFile(file);
        setFileName(file.name);
        setLegalText(''); 

        const reader = new FileReader();
        reader.onload = (event) => {
          const fileContent = event.target?.result as string;
          setLegalText(fileContent);
           toast({
            title: 'Arquivo Carregado',
            description: `Conteúdo de "${file.name}" carregado.`,
          });
        };
        reader.onerror = () => {
           toast({
            title: 'Erro ao Ler Arquivo',
            description: 'Não foi possível ler o conteúdo do arquivo.',
            variant: 'destructive',
          });
          clearFileSelection();
        }
        reader.readAsText(file);

      } else if (file.type === 'application/pdf' || file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        setSelectedFile(file);
        setFileName(file.name);
        setLegalText('');
        toast({
          title: 'Tipo de Arquivo Não Suportado Diretamente',
          description: `Arquivos PDF e DOCX ainda não são processados diretamente no navegador. A análise pode não funcionar corretamente. Considere colar o texto ou usar um arquivo .txt.`,
          variant: 'default',
          duration: 7000,
        });
        setLegalText(`Arquivo selecionado: ${file.name} (tipo não processado no navegador)`);
      } else {
         toast({
          title: 'Tipo de Arquivo Inválido',
          description: 'Por favor, selecione um arquivo .txt, .pdf ou .docx.',
          variant: 'destructive',
        });
        clearFileSelection();
      }
    } else {
      clearFileSelection();
    }
  };

  const handleTextAnalysis = async () => {
    let textToAnalyze = legalText.trim();

    if (selectedFile && selectedFile.type !== 'text/plain') {
       toast({
          title: 'Análise Limitada',
          description: `Analisando apenas o nome do arquivo "${fileName}". A extração de texto para este tipo de arquivo não é suportada no navegador.`,
          variant: 'default',
        });
       textToAnalyze = `Analisando o documento ${fileName}`;
    }


    if (!textToAnalyze && !selectedFile) {
        toast({
            title: 'Nenhum Conteúdo para Análise',
            description: 'Por favor, insira um texto jurídico ou selecione um arquivo.',
            variant: 'destructive',
        });
        return;
    }
     if (!textToAnalyze && selectedFile && selectedFile.type !== 'text/plain') {
         toast({
             title: 'Análise Não Disponível',
             description: `Não é possível analisar o conteúdo do arquivo "${fileName}" diretamente. Por favor, cole o texto ou use um arquivo .txt.`,
             variant: 'destructive',
         });
         return;
     }


    setIsLoadingAnalysis(true);
    setEntities([]);
    setSelectedEntity(null);
    setSelectedEntityContexts([]);
    setDocumentType(null);
    setLegalSummary(null); // Reset summary

    try {
      const [entityResult, classificationResult, summaryResult] = await Promise.all([
        extractLegalEntities({ legalText: textToAnalyze }),
        classifyLegalDocument({ legalText: textToAnalyze }),
        summarizeLegalDocument({ legalText: textToAnalyze }) // Add summary call
      ]);

      if (entityResult.entities && entityResult.entities.length > 0) {
        setEntities(entityResult.entities);
      } else {
        setEntities([]);
      }

      if (classificationResult.documentType) {
        setDocumentType(classificationResult.documentType);
      } else {
        setDocumentType("Tipo Não Identificado");
      }

      if (summaryResult) {
        setLegalSummary(summaryResult);
      } else {
        setLegalSummary({ // Default/error state for summary
            overallSummary: "Não foi possível gerar o resumo.",
            mainRequests: [],
            legalGrounds: [],
            legalBasisCited: []
        });
      }

        let toastDescription = '';
        if (entityResult.entities && entityResult.entities.length > 0) {
            toastDescription += `${entityResult.entities.length} entidade(s) extraída(s). `;
        } else {
            toastDescription += 'Nenhuma entidade extraída. ';
        }
        if (classificationResult.documentType && classificationResult.documentType !== "Tipo Não Identificado" && classificationResult.documentType !== "Erro na Classificação" && classificationResult.documentType !== "Informação Insuficiente para Classificar") {
            toastDescription += `Doc classificado: "${classificationResult.documentType}". `;
        } else {
             toastDescription += 'Tipo do doc não identificado. ';
        }
        if (summaryResult && summaryResult.overallSummary && summaryResult.overallSummary !== "Informação Insuficiente para Resumir." && summaryResult.overallSummary !== "Erro ao gerar resumo.") {
            toastDescription += 'Resumo gerado.';
        } else {
            toastDescription += 'Resumo não gerado.';
        }


        toast({
            title: 'Análise Concluída',
            description: toastDescription.trim(),
         });


    } catch (error) {
      console.error('Error during analysis:', error);
      toast({
        title: 'Erro na Análise',
        description: 'Ocorreu um erro ao analisar o documento. Tente novamente.',
        variant: 'destructive',
      });
       setEntities([]);
       setDocumentType(null);
       setLegalSummary(null); // Clear summary on error
    } finally {
      setIsLoadingAnalysis(false);
    }
  };

  const handleEntitySelect = async (entity: LegalEntity) => {
      let textForContext = legalText.trim();

       if (selectedFile && selectedFile.type !== 'text/plain') {
            toast({
                title: 'Contexto Não Disponível',
                description: `Não é possível localizar o contexto dentro do arquivo "${fileName}" diretamente no navegador.`,
                variant: 'default',
            });
           setSelectedEntity(null);
           setSelectedEntityContexts([]);
           return;
       }


      if (!textForContext) {
          toast({
            title: 'Texto Faltando',
            description: 'O texto jurídico original não está disponível para encontrar o contexto.',
            variant: 'destructive',
          });
          return;
      }

      if (selectedEntity?.name === entity.name && selectedEntity?.type === entity.type) {
          setSelectedEntity(null);
          setSelectedEntityContexts([]);
          return;
      }

      setSelectedEntity(entity);
      setIsLoadingContext(true);
      setSelectedEntityContexts([]);

      try {
          const result = await locateEntityContext({ legalText: textForContext, entity: entity.name });
          if (result.contexts && result.contexts.length > 0) {
              setSelectedEntityContexts(result.contexts);
               toast({
                    title: 'Contexto Localizado',
                    description: `${result.contexts.length} contexto(s) encontrado(s) para "${entity.name}".`,
                });
          } else {
              setSelectedEntityContexts([]);
              toast({
                  title: 'Contexto não Encontrado',
                  description: `Nenhum contexto encontrado para "${entity.name}".`,
              });
          }
      } catch (error) {
          console.error('Error locating entity context:', error);
          toast({
              title: 'Erro ao Localizar Contexto',
              description: 'Ocorreu um erro ao buscar o contexto da entidade. Tente novamente.',
              variant: 'destructive',
          });
          setSelectedEntityContexts([]);
      } finally {
          setIsLoadingContext(false);
      }
  };


  return (
    <div className="grid md:grid-cols-2 gap-6 lg:gap-8 items-start">
      <div className="flex flex-col gap-6 lg:gap-8">
        {/* Input Card */}
        <Card className="shadow-lg">
          <CardHeader>
            <div className="flex items-center gap-2 text-primary">
              <FileText className="h-6 w-6" />
              <CardTitle className="text-xl">Entrada de Texto Jurídico</CardTitle>
            </div>
            <CardDescription>Cole o texto ou envie um arquivo (.txt, .pdf, .docx).</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              placeholder="Cole aqui o texto jurídico..."
              value={legalText}
              onChange={handleTextChange}
              rows={8}
              className="min-h-[150px] text-sm rounded-md focus:ring-accent focus:border-accent transition-shadow duration-150 ease-in-out shadow-inner"
              disabled={isLoadingAnalysis || (!!selectedFile && selectedFile.type !== 'text/plain')}
            />
            <div className="text-center text-sm text-muted-foreground my-2">OU</div>
            <div className="flex flex-col items-center gap-2">
                <Label htmlFor="file-upload" className={cn(
                    "flex items-center gap-2 px-4 py-2 border border-input rounded-md cursor-pointer hover:bg-secondary transition-colors w-full justify-center",
                    isLoadingAnalysis && "opacity-50 cursor-not-allowed"
                )}>
                    <Upload className="h-4 w-4" />
                    <span>{fileName ? "Trocar Arquivo" : "Enviar Arquivo (.txt, .pdf, .docx)"}</span>
                </Label>
                 <Input
                    id="file-upload"
                    ref={fileInputRef}
                    type="file"
                    accept=".txt,.pdf,.docx,text/plain,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    onChange={handleFileChange}
                    className="hidden"
                    disabled={isLoadingAnalysis}
                 />
                 {fileName && (
                    <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground bg-secondary p-2 rounded-md w-full max-w-sm truncate">
                        <FileText className="h-4 w-4 flex-shrink-0" />
                        <span className="truncate flex-grow text-left">{fileName}</span>
                        <Button variant="ghost" size="icon" className="h-6 w-6" onClick={clearFileSelection} disabled={isLoadingAnalysis} aria-label="Remover arquivo">
                            <X className="h-4 w-4" />
                        </Button>
                    </div>
                 )}
            </div>
             <p className="text-xs text-muted-foreground text-center mt-2">
                Nota: Arquivos PDF e DOCX são aceitos, mas a extração de texto ocorre no navegador apenas para arquivos .txt. A análise de PDF/DOCX pode ser limitada.
            </p>
          </CardContent>
          <CardFooter>
            <Button
              onClick={handleTextAnalysis}
              disabled={isLoadingAnalysis || (!legalText.trim() && !selectedFile)}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground transition-all duration-150 ease-in-out transform hover:scale-105"
            >
              {isLoadingAnalysis ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <ListChecks className="mr-2 h-4 w-4" />
              )}
              Analisar {selectedFile ? 'Arquivo' : 'Texto'}
            </Button>
          </CardFooter>
        </Card>

        {/* Classification Card */}
        {isLoadingAnalysis ? (
            <ClassificationSkeleton />
        ) : documentType ? (
             <Card className="shadow-lg">
                <CardHeader>
                    <div className="flex items-center gap-2 text-primary">
                    <Gavel className="h-6 w-6" />
                    <CardTitle className="text-xl">Classificação da Peça</CardTitle>
                    </div>
                    <CardDescription>Tipo de documento jurídico identificado.</CardDescription>
                </CardHeader>
                <CardContent>
                    <p className="text-lg font-semibold text-center text-accent">{documentType}</p>
                </CardContent>
             </Card>
        ) : null }

        {/* Summary Card - NEW */}
        {isLoadingAnalysis ? (
            <SummarySkeleton />
        ) : legalSummary ? (
            <Card className="shadow-lg">
                <CardHeader>
                    <div className="flex items-center gap-2 text-primary">
                        <ScrollText className="h-6 w-6" />
                        <CardTitle className="text-xl">Resumo Jurídico</CardTitle>
                    </div>
                    <CardDescription>Principais pontos do documento analisado.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 text-sm">
                    {legalSummary.overallSummary && legalSummary.overallSummary !== "Informação Insuficiente para Resumir." && legalSummary.overallSummary !== "Erro ao gerar resumo." && (
                        <div>
                            <h4 className="font-semibold text-primary mb-1">Resumo Geral</h4>
                            <p className="text-foreground whitespace-pre-wrap">{legalSummary.overallSummary}</p>
                        </div>
                    )}
                    {legalSummary.mainRequests && legalSummary.mainRequests.length > 0 && (
                        <div>
                            <h4 className="font-semibold text-primary mb-1">Pedidos Encontrados</h4>
                            <ul className="list-disc list-inside pl-2 space-y-1 text-foreground">
                                {legalSummary.mainRequests.map((req, i) => <li key={`req-${i}`}>{req}</li>)}
                            </ul>
                        </div>
                    )}
                    {legalSummary.legalGrounds && legalSummary.legalGrounds.length > 0 && (
                        <div>
                            <h4 className="font-semibold text-primary mb-1">Fundamentos Jurídicos</h4>
                            <ul className="list-disc list-inside pl-2 space-y-1 text-foreground">
                                {legalSummary.legalGrounds.map((ground, i) => <li key={`ground-${i}`}>{ground}</li>)}
                            </ul>
                        </div>
                    )}
                    {legalSummary.legalBasisCited && legalSummary.legalBasisCited.length > 0 && (
                        <div>
                            <h4 className="font-semibold text-primary mb-1">Base Legal Citada</h4>
                            <ul className="list-disc list-inside pl-2 space-y-1 text-foreground">
                                {legalSummary.legalBasisCited.map((basis, i) => <li key={`basis-${i}`}>{basis}</li>)}
                            </ul>
                        </div>
                    )}
                     {(legalSummary.overallSummary === "Informação Insuficiente para Resumir." || legalSummary.overallSummary === "Erro ao gerar resumo.") && 
                        (!legalSummary.mainRequests || legalSummary.mainRequests.length === 0) &&
                        (!legalSummary.legalGrounds || legalSummary.legalGrounds.length === 0) &&
                        (!legalSummary.legalBasisCited || legalSummary.legalBasisCited.length === 0) && (
                         <p className="text-muted-foreground text-center">{legalSummary.overallSummary}</p>
                     )}
                </CardContent>
            </Card>
        ) : null}


        {/* Entities Card */}
        <Card className="shadow-lg">
          <CardHeader>
             <div className="flex items-center gap-2 text-primary">
                <ListChecks className="h-6 w-6" />
                <CardTitle className="text-xl">Entidades Extraídas</CardTitle>
            </div>
            <CardDescription>Lista de pessoas, empresas e organizações identificadas.</CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[250px] pr-3">
              {isLoadingAnalysis ? (
                <EntityListSkeleton />
              ) : entities.length > 0 ? (
                <div className="space-y-2">
                  {entities.map((entity) => (
                    <EntityListItem
                      key={`${entity.name}-${entity.type}`}
                      entity={entity}
                      isSelected={selectedEntity?.name === entity.name && selectedEntity?.type === entity.type}
                      onSelect={() => handleEntitySelect(entity)}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center text-muted-foreground py-10">
                  <ListChecks className="mx-auto h-12 w-12 mb-2 opacity-50" />
                  <p>Nenhuma entidade extraída.</p>
                  <p className="text-sm">Analise um texto ou arquivo para visualizar.</p>
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Context Viewer Card */}
      <Card className="shadow-lg md:sticky md:top-8">
        <CardHeader>
            <div className="flex items-center gap-2 text-primary">
                <SearchCheck className="h-6 w-6" />
                <CardTitle className="text-xl">Localizador de Contexto</CardTitle>
            </div>
          <CardDescription>
            {selectedEntity
              ? `Contextos onde "${selectedEntity.name}" é mencionado(a).`
              : "Selecione uma entidade para ver seus contextos."}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[calc(100vh-12rem)] min-h-[400px] max-h-[750px] pr-3">
            {isLoadingContext ? (
              <ContextViewerSkeleton />
            ) : selectedEntity ? (
              selectedEntityContexts.length > 0 ? (
                <div className="space-y-4">
                  {selectedEntityContexts.map((context, index) => (
                    <div key={index} className="p-4 bg-secondary rounded-md shadow-sm border border-border">
                      <p className="text-sm leading-relaxed text-secondary-foreground whitespace-pre-wrap">
                         {highlightEntity(context, selectedEntity.name)}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                 isLoadingContext ? <ContextViewerSkeleton /> :
                 <div className="text-center text-muted-foreground py-10">
                    <SearchCheck className="mx-auto h-12 w-12 mb-2 opacity-50" />
                    <p>Nenhum contexto encontrado para "{selectedEntity.name}".</p>
                 </div>
              )
            ) : (
              <div className="text-center text-muted-foreground py-10">
                 <AlertTriangle className="mx-auto h-12 w-12 mb-2 opacity-50" />
                <p>Selecione uma entidade</p>
                <p className="text-sm">Escolha uma entidade da lista à esquerda.</p>
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

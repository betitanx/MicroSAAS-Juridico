import type {Metadata} from 'next';
import { GeistSans } from 'geist/font/sans';
// Removed GeistMono import as it's not used and caused a build error
import './globals.css';
import { Toaster } from "@/components/ui/toaster";

const geistSans = GeistSans;
// Removed geistMono variable

export const metadata: Metadata = {
  title: 'Juri AI', // Updated title
  description: 'Ferramenta de IA para análise de textos jurídicos',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    // Removed geistMono.variable from className
    <html lang="pt-BR" className={`${geistSans.variable}`}>
      <body className={`antialiased font-sans`}>
        {children}
        <Toaster />
      </body>
    </html>
  );
}

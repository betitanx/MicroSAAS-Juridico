import Header from '@/components/layout/header';
import LegalAssistantClient from '@/components/assistente-juridico/legal-assistant-client';

export default function AssistenteJuridicoPage() {
  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      <main className="flex-grow container mx-auto p-4 sm:p-6 lg:p-8">
        <LegalAssistantClient />
      </main>
      <footer className="py-6 text-center text-sm text-muted-foreground border-t">
        {/* Updated copyright text */}
        <p>&copy; {new Date().getFullYear()} Juri AI. Todos os direitos reservados.</p>
      </footer>
    </div>
  );
}
